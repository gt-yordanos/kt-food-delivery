export const chapaConfig = {
  chapaSecretKey: process.env.CHAPA_API_KEY,
  baseUrl: process.env.BASE_URL
};